import React from 'react'

function AboutMovie() {
    return (<>
        <h1 className="text-light p-3 ">About Movie</h1>
      
      <div className=" bg-dark right-detail">
        <div className="rdetail-row1 mt flx"><p className="lbl">Cast: </p> <p className="txt m">Lee Jung-jae ,Gong Yoo and Lee Byung Hun</p></div>
        <div className="rdetail-row2 mt flx"><p className="lbl">Genres: </p> <p className="txt m">Survival,Thriller,Horror[1],Drama</p></div>
        <div className="rdetail-row3 mt flx"><p className="lbl">The Show is: </p> <p className="txt m">suspenful</p></div>
      </div> 
</>
    )
}

export default AboutMovie
