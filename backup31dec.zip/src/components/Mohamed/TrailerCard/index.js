import React from 'react'

function TrailerCard() {
    return (
        
              <div class="col col-12 col-sm-6 col-md-4 col-lg-3 mb-3">
      <div class=" border-0 ">
        <img src="/images/2.jpeg" class="card-img-top" alt="..." />
        <div class="card-body scard-hover text-light position-relative ">
          <p class="card-text">
            This is a longer card with supporting text below as a natural
            lead-in to additional content. 
          </p>
        </div>
      </div>
    </div>

    )
}

export default TrailerCard
